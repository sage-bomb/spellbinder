async function showAllFiles() {
    const response = await fetch('/list_files');
    const data = await response.json();
    const resultsDiv = document.getElementById('results');

    resultsDiv.innerHTML = '<h3>All Files</h3>' + data.files.map(file => `
        <div class="file-card">
            <div>
                <b>${file.filename}</b> (Size: ${file.size} bytes)<br>
                <small>EID: ${file.eid}</small>
            </div>
            <div class="result-tags">
                ${file.tags.map(tag => `<span class="tag" onclick="removeTag('${file.eid}', '${tag}')">${tag} ✕</span>`).join('')}
            </div>
            <div>
                <button onclick="readFile('${file.eid}')">Open</button>
                <button onclick="promptAddTag('${file.eid}')">Add Tag</button>
            </div>
        </div>
    `).join('');
}

async function readFile(eid) {
    const response = await fetch(`/open_file?eid=${encodeURIComponent(eid)}`);
    const data = await response.json();
    document.getElementById('readerFilename').textContent = `File: ${data.filename}`;
    document.getElementById('readerContent').textContent = data.content;
    document.getElementById('readerApp').style.display = 'flex';
}

async function promptAddTag(eid) {
    const tag = prompt("Enter tag to add:");
    if (tag) {
        const formData = new FormData();
        formData.append("eid", eid);
        formData.append("tag", tag);
        await fetch('/add_tag', { method: 'POST', body: formData });
        alert("Tag added.");
        showAllFiles();
    }
}

async function removeTag(eid, tag) {
    const formData = new FormData();
    formData.append("eid", eid);
    formData.append("tag", tag);
    await fetch('/remove_tag', { method: 'POST', body: formData });
    alert("Tag removed.");
    showAllFiles();
}